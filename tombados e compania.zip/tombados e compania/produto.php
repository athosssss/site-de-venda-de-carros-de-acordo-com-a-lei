<?php
$ido=$_GET["butao"];
include_once 'assets/header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>home principal 2</title>
<link rel="stylesheet" href="styles/produto.css">
</head>
<?php
include_once 'includes/_dados.php'
?>

<body>
<article>
<img src="<?php echo$produtos[$ido]["link"] ?>" alt="">
<h2><?php echo$produtos[$ido]["nome"] ?></h2>
<p>Nos somos legalmente obrigados a informar que nosso <?php echo$produtos[$ido]["nome"]?> é produto adquirido de maneira legal e padronizados para melhor qualidade pelo menor preço, todos veem com imagems do antigo motorista (com ou sem vida, por escolha do comprador), e tambem uma foto do modelo do carro e placa em caso de dificil indentificação, mas podemos dizer com orgulho que nosso <?php echo$produtos[$ido]["nome"]?> é feito com muito amor, e de maneira proposital </p>
<h3><?php echo$produtos[$ido]["preco"]?></h3>
<button>compre</button>
</article>
</body>