<?php
$id=$_GET['nome'];
$id1=$_GET['gmail'];
$id2=$_GET['mensagem'];
var_dump($_GET);
?>