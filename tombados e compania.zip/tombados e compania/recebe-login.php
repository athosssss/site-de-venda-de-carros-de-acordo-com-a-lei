<?php
$id1=$_GET['gmail'];
$id=$_GET['senha'];
var_dump($_GET);
?>