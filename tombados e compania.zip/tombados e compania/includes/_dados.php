<?php
$produtos=array(
0=>array(
"nome"=>"Tombado 12h",
"link"=>"produtos/de pé.webp",
"preco"=>"R$15,50",
"descricao"=>"",
),

1=>array(
"nome"=> "fuligem e desconto",
"link"=>"produtos/fusca.jpg",
"preco"=>"R$3.99",
"descricao"=>"",
),

2=>array(
"nome"=>"Pronta-entrega",
"link"=>"produtos/gif.gif",
"preco"=>"R$55.00",
"descricao"=>"",
),

3=>array(
"nome"=>"Tronco não incluso",
"link"=>"produtos/tronco.jpg",
"preco"=>"R$800.00",
"descricao"=>"",
),

4=>array(
"nome"=>"Feito na hora",
"link"=>"produtos/destruido.jpg",
"preco"=>"1,99",
"descricao"=>"",
),

5=>array(
"nome"=>"aearado deluxe",
"link"=>"produtos/entrega.gif",
"preco"=>"R$99.99",
"descricao"=>"",
),

6=>array(
"nome"=>"mergulhado em calda",
"link"=>"produtos/mar.jpg",
"preco"=>"R$45.00",
"descricao"=>"",
),

7=>array(
"nome"=>"spicy nachos edition",
"link"=>"produtos/fogo.jpg",
"preco"=>"R$13.00",
"descricao"=>"",
),

8=>array(
"nome"=>"entrega aerea",
"link"=>"produtos/voador.webp",
"preco"=>"R$1500.00",
"descricao"=>"",
),
9=>array(
"nome"=>"car bits",
"link"=>"produtos/quadro.jpg",
"preco"=>"R$5.00",
"descricao"=>"",
)

);
$categorias=array(
0=>array(
"nome"=>"CARROS SÉRIOS",
"link"=>"categorias/chad.jpg"
),

1=>array(
"nome"=>"1900 e 80 socos",
"link"=>"categorias/dano.jpg"
),

2=>array(
"nome"=>"Piramides da demolição",
"link"=>"categorias/juntos.jpg"
),

3=>array(
"nome"=>"Mofados com amor",
"link"=>"categorias/fodas.jpeg"
),

4=>array(
"nome"=>"Semi novos",
"link"=>"categorias/novo.jpg"
),

5=>array(
"nome"=>"Carraquaticos",
"link"=>"categorias/agua.jpg"
)

)
?>