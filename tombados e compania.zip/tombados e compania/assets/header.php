<?php 
include_once 'head.php';
?>
<body>
<div class="header">
<a href="categorias.php"><img src="imagens/logo.png" id="logo"></a>
<nav>
<ul>
<a href="categorias.php"><li>home principal</li></a>
<a href="produtos.php"><li>todos os produtos</li></a>
<a href="contatos.php"><li>todos os contatos</li></a>
<a href="login.php"><li>pagina de login</li></a>
<a href="cadastro.php"><li>pagina de cadastro</li></a>
</ul>
</nav>
</div>    
</body>