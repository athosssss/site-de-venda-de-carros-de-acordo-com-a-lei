<?php
$id=$_GET['senha'];
$id1=$_GET['gmail'];
$id2=$_GET['num'];
$id3=$_GET['nome'];
var_dump($_GET);
?>